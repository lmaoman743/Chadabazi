import './globals.css';
import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { Noto_Sans_Bengali } from 'next/font/google';
import { I18nProvider } from '@/components/I18nProvider';
import { QuickExit } from '@/components/QuickExit';
import { DEFAULT_LANG, LANG_COOKIE, isLang } from '@/lib/i18n';

// One font that covers both Bangla and English text.
const font = Noto_Sans_Bengali({ subsets: ['bengali', 'latin'], display: 'swap' });

export const metadata: Metadata = {
  title: 'Anonymous Chadabazi Reporting Platform',
  description: 'Report extortion safely and anonymously, and follow what happens to your complaint.',
  robots: { index: false, follow: false },
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const saved = (await cookies()).get(LANG_COOKIE)?.value;
  const lang = isLang(saved) ? saved : DEFAULT_LANG;
  return (
    <html lang={lang}>
      <body className={font.className}>
        <I18nProvider initial={lang}>
          {children}
          <QuickExit />
        </I18nProvider>
      </body>
    </html>
  );
}
