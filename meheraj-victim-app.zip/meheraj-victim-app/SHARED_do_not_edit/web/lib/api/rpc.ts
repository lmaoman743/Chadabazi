import type { SupabaseClient } from '@supabase/supabase-js';
import { HttpError } from '@/lib/security/http';

// The workflow functions in 003_workflow.sql raise short codes. This turns them into
// HTTP errors whose messages are safe to show.
const KNOWN: Record<string, [number, string]> = {
  report_not_found: [404, 'Report not found.'],
  report_not_draft: [409, 'This report was already submitted.'],
  evidence_required: [400, 'Add at least one piece of evidence before submitting.'],
  report_not_under_review: [409, 'This case is not open for review.'],
  not_assigned: [403, 'This case is not assigned to you.'],
  already_reviewed: [409, 'You have already reviewed this case.'],
  checklist_required: [400, 'The checklist is required.'],
  checklist_failed: [400, 'Every checklist item must pass before a case can be marked valid.'],
  reason_required: [400, 'A category and a written reason are required.'],
  invalid_decision: [400, 'Invalid decision.'],
  not_rejected: [409, 'Only a rejected report can be appealed.'],
  already_appealed: [409, 'This report was already appealed. An appeal can be made only once.'],
  no_reviewers_available: [503, 'No reviewers are available right now. Please try again later.'],
  report_not_assessable: [409, 'This case cannot be ranked yet.'],
  already_assessed: [409, 'This case already has an urgency level.'],
  invalid_level: [400, 'Invalid urgency level.'],
  not_ready_to_forward: [409, 'Only a valid case with an urgency level can be forwarded.'],
  not_forwarded: [409, 'This case has not been forwarded to the police yet, or is already closed.'],
  invalid_stage: [400, 'Invalid case stage.'],
  daily_report_limit: [429, 'You can create at most 3 reports in 24 hours.'],
};

export function mapDbError(message: string | undefined): HttpError {
  const entry = message ? KNOWN[message] : undefined;
  if (entry) return new HttpError(entry[0], message as string, entry[1]);
  return new HttpError(500, 'server_error', 'Something went wrong.');
}

/** Calls a workflow function with the service-role client and throws a clean HttpError on failure. */
export async function callRpc<T = unknown>(admin: SupabaseClient, fn: string, args: Record<string, unknown>): Promise<T> {
  const { data, error } = await admin.rpc(fn, args);
  if (error) throw mapDbError(error.message);
  return data as T;
}
