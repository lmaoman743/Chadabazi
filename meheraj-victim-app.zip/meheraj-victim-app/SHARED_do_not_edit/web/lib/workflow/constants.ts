// Values shared by the database (001/003), the API routes and the screens.
// If you change a list here, change the matching CHECK constraint in supabase/migrations/001_base_schema.sql.

export const CHADABAZI_TYPES = ['protection_money', 'business_toll', 'transport_toll', 'construction_contract', 'land_property', 'other'] as const;
export const REPORT_STATUSES = ['draft', 'submitted', 'under_review', 'rejected', 'valid', 'forwarded_to_police', 'under_investigation', 'closed'] as const;
export const REJECTION_CATEGORIES = ['insufficient_evidence', 'not_chadabazi', 'unclear_or_unreadable', 'duplicate', 'suspected_false'] as const;
export const URGENCY_LEVELS = ['critical', 'high', 'medium', 'low'] as const;
export const CASE_STAGES = ['forwarded', 'investigating', 'charge_sheet', 'trial', 'closed'] as const;

/** Compliance checklist an Evidence Reviewer completes (FR-13). A "valid" decision needs every item ticked. */
export const CHECKLIST_ITEMS = [
  'shows_demand_or_threat',
  'relates_to_reported_incident',
  'readable_and_complete',
  'no_sign_of_editing',
  'hash_recorded',
] as const;

/** Largest file each kind may be (MB). Mirrors processing-service/src/config.js; the server enforces the real limit. */
export const FILE_LIMITS_MB = { image: 10, pdf: 10, audio: 25, video: 50 } as const;

/** Reports a victim may create per 24 hours (database trigger in 003). */
export const MAX_REPORTS_PER_DAY = 3;

export type ReportStatus = (typeof REPORT_STATUSES)[number];
export type UrgencyLevel = (typeof URGENCY_LEVELS)[number];
export type CaseStage = (typeof CASE_STAGES)[number];

/** Sort key: Critical first. Used by the urgency and case queues (FR-14). */
export function urgencyRank(level: string | null | undefined): number {
  const i = URGENCY_LEVELS.indexOf(level as UrgencyLevel);
  return i === -1 ? URGENCY_LEVELS.length : i;
}

/**
 * Urgency queue order (TC-09): fast-track first, then Critical, High, Medium, Low (not yet ranked = last
 * within its group), then oldest first.
 */
export function compareUrgencyQueue(
  a: { fast_track: boolean; level?: string | null; created_at: string },
  b: { fast_track: boolean; level?: string | null; created_at: string },
): number {
  if (a.fast_track !== b.fast_track) return a.fast_track ? -1 : 1;
  const byLevel = urgencyRank(a.level) - urgencyRank(b.level);
  if (byLevel !== 0) return byLevel;
  return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
}
