import { z } from 'zod';
import { CASE_STAGES, CHADABAZI_TYPES, CHECKLIST_ITEMS, REJECTION_CATEGORIES, URGENCY_LEVELS } from './constants';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const idSchema = z.string().regex(UUID_RE);

// Note: readJson() refuses bodies over 10,000 bytes. Bangla letters take 3 bytes each, so the
// text limits below keep a full Bangla report under that size.
export const createReportSchema = z.object({
  location_id: z.number().int().positive(),
  chadabazi_type: z.enum(CHADABAZI_TYPES),
  amount_demanded: z.number().min(0).max(100_000_000_000),
  incident_date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .refine((d) => !Number.isNaN(Date.parse(d)) && Date.parse(d) <= Date.now() + 24 * 3600_000, 'future_date'),
  description: z.string().trim().min(10).max(2000),
  accused_description: z.string().trim().max(500).optional().or(z.literal('')),
  fast_track: z.boolean().default(false),
});

export const appealSchema = z.object({ reason: z.string().trim().min(10).max(1000) });

const checklistShape = Object.fromEntries(CHECKLIST_ITEMS.map((k) => [k, z.boolean()])) as Record<(typeof CHECKLIST_ITEMS)[number], z.ZodBoolean>;

export const reviewSchema = z
  .object({
    decision: z.enum(['valid', 'rejected']),
    rejection_category: z.enum(REJECTION_CATEGORIES).optional(),
    reason: z.string().trim().max(1000).optional(),
    checklist: z.object(checklistShape).strict(),
  })
  .superRefine((v, ctx) => {
    if (v.decision === 'valid' && Object.values(v.checklist).some((x) => !x)) {
      ctx.addIssue({ code: 'custom', message: 'checklist_failed', path: ['checklist'] });
    }
    // TC-08: a rejection without a category and a written reason is not saved.
    if (v.decision === 'rejected' && (!v.rejection_category || (v.reason ?? '').length < 10)) {
      ctx.addIssue({ code: 'custom', message: 'reason_required', path: ['reason'] });
    }
  });

export const urgencySchema = z.object({ level: z.enum(URGENCY_LEVELS), note: z.string().trim().max(1000).optional() });

export const caseUpdateSchema = z.object({
  stage: z.enum(CASE_STAGES),
  expected_days: z.number().int().min(0).max(3650).nullable().optional(),
  details: z.string().trim().max(2000).optional(),
});

export const flagActionSchema = z.object({ action: z.enum(['block', 'dismiss']) });
