import { en } from './en';
import { bn } from './bn';

export type Lang = 'en' | 'bn';
export const LANGS: readonly Lang[] = ['en', 'bn'];
export const DEFAULT_LANG: Lang = 'en';
export const LANG_COOKIE = 'lang';

const dictionaries: Record<Lang, Record<string, string>> = { en, bn };

export function isLang(v: unknown): v is Lang {
  return v === 'en' || v === 'bn';
}

/** Looks a key up in the chosen language, falls back to English, then to the key itself. {name} placeholders are filled from vars. */
export function translate(lang: Lang, key: string, vars?: Record<string, string | number>): string {
  const text = dictionaries[lang][key] ?? dictionaries.en[key] ?? key;
  if (!vars) return text;
  return text.replace(/\{(\w+)\}/g, (_, name: string) => (name in vars ? String(vars[name]) : `{${name}}`));
}

/** True when the key exists in the dictionary (used for dynamic keys such as "status.valid"). */
export function hasKey(key: string): boolean {
  return key in en;
}
