import type { Lang } from '@/lib/i18n';

const locale = (lang: Lang) => (lang === 'bn' ? 'bn-BD' : 'en-GB');

export function formatDate(iso: string, lang: Lang): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString(locale(lang), { year: 'numeric', month: 'short', day: 'numeric' });
}

export function formatDateTime(iso: string, lang: Lang): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString(locale(lang), { dateStyle: 'medium', timeStyle: 'short' });
}

export function formatMoney(n: number, lang: Lang): string {
  return `৳ ${new Intl.NumberFormat(locale(lang)).format(n)}`;
}
