// Small fetch wrapper for the browser. Throws ApiError with the server's error code,
// so screens can show a translated message ("err.<code>").
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public data: Record<string, unknown> = {},
  ) {
    super(message);
  }
}

export async function api<T = unknown>(url: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method: init.method ?? (init.body === undefined ? 'GET' : 'POST'),
      headers: init.body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: init.body === undefined ? undefined : JSON.stringify(init.body),
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError(0, 'network', 'Network error');
  }
  const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;
  if (!res.ok) throw new ApiError(res.status, String(data.error ?? 'server_error'), String(data.message ?? 'Request failed'), data);
  return data as T;
}

/** Translated text for an error: uses "err.<code>" when it exists, else "err.generic". */
export function errorText(e: unknown, t: (key: string, vars?: Record<string, string | number>) => string, has: (key: string) => boolean): string {
  if (e instanceof ApiError) {
    const key = `err.${e.code}`;
    if (has(key)) return t(key, { n: Number(e.data.attemptsLeft ?? 0), s: Number(e.data.retryAfterSeconds ?? 0) });
  }
  return t('err.generic');
}

export function roleHome(role: string): string {
  switch (role) {
    case 'evidence_reviewer':
      return '/staff/evidence';
    case 'urgency_reviewer':
      return '/staff/urgency';
    case 'case_officer':
      return '/staff/case';
    case 'admin':
      return '/admin';
    default:
      return '/victim';
  }
}
