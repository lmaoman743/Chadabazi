'use client';
import { useI18n } from './I18nProvider';

const COLORS: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-700',
  submitted: 'bg-blue-100 text-blue-800',
  under_review: 'bg-blue-100 text-blue-800',
  rejected: 'bg-red-100 text-red-800',
  valid: 'bg-emerald-100 text-emerald-800',
  forwarded_to_police: 'bg-indigo-100 text-indigo-800',
  under_investigation: 'bg-indigo-100 text-indigo-800',
  closed: 'bg-slate-200 text-slate-800',
};

export function StatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return (
    <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${COLORS[status] ?? 'bg-slate-100 text-slate-700'}`}>
      {t(`status.${status}`)}
    </span>
  );
}
