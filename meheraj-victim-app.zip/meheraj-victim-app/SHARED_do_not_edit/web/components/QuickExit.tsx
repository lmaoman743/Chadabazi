'use client';
import { useEffect, useRef } from 'react';
import { useI18n } from './I18nProvider';

/**
 * Quick-exit (FR-24): leaves the site at once if someone walks in.
 * Click the button, or press Escape twice quickly. The page is replaced in history, so
 * the Back button does not return to it from this tab.
 */
export function QuickExit() {
  const { t } = useI18n();
  const last = useRef(0);

  const leave = () => {
    try {
      sessionStorage.clear();
    } catch {
      /* ignore */
    }
    window.location.replace('https://www.google.com/');
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      const now = Date.now();
      if (now - last.current < 600) window.location.replace('https://www.google.com/');
      last.current = now;
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <button
      type="button"
      onClick={leave}
      title={t('quickExit.hint')}
      className="fixed bottom-4 right-4 z-50 rounded-full bg-red-700 px-4 py-3 text-sm font-bold text-white shadow-lg hover:bg-red-800 focus:outline-none focus:ring-4 focus:ring-red-300"
    >
      {t('quickExit.button')}
    </button>
  );
}
