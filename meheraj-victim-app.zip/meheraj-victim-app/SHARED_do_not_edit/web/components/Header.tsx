'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createBrowserSupabase } from '@/lib/supabase/client';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useI18n } from './I18nProvider';
import { btnGhost } from './ui';

export interface NavItem {
  href: string;
  labelKey: string;
}

/** Top bar for every signed-in screen: title, optional navigation, language, sign out. */
export function Header({ nav = [], signOutTo = '/', showId }: { nav?: NavItem[]; signOutTo?: string; showId?: string }) {
  const { t } = useI18n();
  const router = useRouter();

  const signOut = async () => {
    await createBrowserSupabase().auth.signOut();
    router.replace(signOutTo);
    router.refresh();
  };

  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-3 px-4 py-3">
        <Link href="/" className="text-base font-bold text-blue-900">
          {t('app.short')}
        </Link>
        <nav className="flex flex-wrap gap-3 text-sm">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className="text-slate-700 underline-offset-4 hover:underline">
              {t(n.labelKey)}
            </Link>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-3">
          {showId ? <span className="rounded bg-slate-100 px-2 py-1 font-mono text-xs text-slate-700">{showId}</span> : null}
          <LanguageSwitcher />
          <button type="button" onClick={signOut} className={btnGhost}>
            {t('common.signOut')}
          </button>
        </div>
      </div>
    </header>
  );
}
