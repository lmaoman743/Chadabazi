// Shared Tailwind class strings, so every screen looks the same.
export const btn =
  'inline-flex items-center justify-center rounded-md bg-blue-800 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-900 disabled:cursor-not-allowed disabled:opacity-50';
export const btnGhost =
  'inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-50';
export const btnDanger =
  'inline-flex items-center justify-center rounded-md bg-red-700 px-4 py-2 text-sm font-semibold text-white hover:bg-red-800 disabled:opacity-50';
export const input =
  'w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600';
export const card = 'rounded-lg border border-slate-200 bg-white p-4 shadow-sm';
export const label = 'mb-1 block text-sm font-medium text-slate-800';
export const errorBox = 'rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800';
export const noteBox = 'rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900';
