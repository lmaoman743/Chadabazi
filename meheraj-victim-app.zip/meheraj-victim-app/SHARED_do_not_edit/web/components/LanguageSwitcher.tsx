'use client';
import { useI18n } from './I18nProvider';

export function LanguageSwitcher() {
  const { lang, setLang } = useI18n();
  return (
    <div className="inline-flex overflow-hidden rounded-md border border-slate-300 text-sm" role="group" aria-label="Language">
      {(['en', 'bn'] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={`px-3 py-1 ${lang === l ? 'bg-blue-800 text-white' : 'bg-white text-slate-800 hover:bg-slate-50'}`}
        >
          {l === 'en' ? 'English' : 'বাংলা'}
        </button>
      ))}
    </div>
  );
}
