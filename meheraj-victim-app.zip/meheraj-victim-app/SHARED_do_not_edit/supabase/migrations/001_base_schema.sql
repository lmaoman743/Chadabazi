-- =============================================================================
-- 001_base_schema.sql   (owner: Md Abir Molla - database schema)
--
-- Creates the tables from the ERD (proposal Figure 4). Run order:
--   001 (this file) -> 002_security_rls_audit.sql (Arafat) -> 003_workflow.sql -> 004_locations_seed.sql
--
-- Every table gets row-level security switched on here with NO policies, so
-- nothing is readable from a browser until 002/003 grant exactly what each role needs.
--
-- Not created on purpose: "messages" (FR-19 is a "Should", not a "Must"). Add it
-- later together with its own RLS policies. identity_hashes / auth_attempts are in 002.
-- =============================================================================

-- ---------------------------------------------------------------- profiles ----
create table if not exists public.profiles (
  user_id         uuid primary key references auth.users (id) on delete cascade,
  pseudonym_id    text not null unique,
  role            text not null check (role in ('victim', 'evidence_reviewer', 'urgency_reviewer', 'case_officer', 'admin')),
  status          text not null default 'active' check (status in ('active', 'suspended', 'blocked')),
  strike_count    integer not null default 0 check (strike_count >= 0),
  -- NULL while suspended = suspended until an admin decides (third strike).
  suspended_until timestamptz,
  created_at      timestamptz not null default now()
);

-- --------------------------------------------------------------- locations ----
-- Bangladesh hierarchy. Rural: division > district > upazila > union > village.
-- City corporations: division > district > city_corporation > thana > ward > area.
create table if not exists public.locations (
  location_id integer primary key,
  parent_id   integer references public.locations (location_id),
  name_en     text not null,
  name_bn     text not null,
  level       text not null check (level in
                ('division', 'district', 'upazila', 'union', 'village', 'city_corporation', 'thana', 'ward', 'area')),
  area_type   text not null default 'rural' check (area_type in ('rural', 'city'))
);
create index if not exists locations_parent_idx on public.locations (parent_id);

-- ----------------------------------------------------------------- reports ----
create table if not exists public.reports (
  report_id           uuid primary key default gen_random_uuid(),
  victim_id           uuid not null references public.profiles (user_id) on delete restrict,
  location_id         integer not null references public.locations (location_id),
  chadabazi_type      text not null check (chadabazi_type in
                        ('protection_money', 'business_toll', 'transport_toll', 'construction_contract', 'land_property', 'other')),
  amount_demanded     numeric(14, 2) not null check (amount_demanded >= 0),
  incident_date       date not null,
  description         text not null check (char_length(description) between 10 and 5000),
  accused_description text check (accused_description is null or char_length(accused_description) <= 2000),
  fast_track          boolean not null default false,
  -- draft: victim is still adding evidence. The other values follow the workflow table in the proposal.
  status              text not null default 'draft' check (status in
                        ('draft', 'submitted', 'under_review', 'rejected', 'valid',
                         'forwarded_to_police', 'under_investigation', 'closed')),
  created_at          timestamptz not null default now()
);
create index if not exists reports_victim_idx on public.reports (victim_id, created_at desc);
create index if not exists reports_status_idx on public.reports (status);

-- ---------------------------------------------------------------- evidence ----
create table if not exists public.evidence (
  evidence_id       uuid primary key default gen_random_uuid(),
  report_id         uuid not null references public.reports (report_id) on delete restrict,
  storage_path      text not null,
  file_type         text not null check (file_type in ('image', 'pdf', 'audio', 'video')),
  sha256            text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  verification_note text,
  uploaded_at       timestamptz not null default now()
);
create index if not exists evidence_report_idx on public.evidence (report_id);

-- -------------------------------------------------------- evidence_reviews ----
create table if not exists public.evidence_reviews (
  review_id          uuid primary key default gen_random_uuid(),
  report_id          uuid not null references public.reports (report_id) on delete restrict,
  reviewer_id        uuid not null references public.profiles (user_id) on delete restrict,
  round              integer not null default 1,  -- 1 = first review, 2 = re-review after an appeal
  decision           text not null check (decision in ('valid', 'rejected')),
  rejection_category text check (rejection_category in
                       ('insufficient_evidence', 'not_chadabazi', 'unclear_or_unreadable', 'duplicate', 'suspected_false')),
  reason             text,
  checklist          jsonb not null default '{}'::jsonb,
  created_at         timestamptz not null default now(),
  unique (report_id, reviewer_id, round),
  -- TC-08: a rejection always needs a category and a written reason.
  check (
    (decision = 'valid' and rejection_category is null)
    or (decision = 'rejected' and rejection_category is not null and char_length(btrim(coalesce(reason, ''))) >= 10)
  )
);
create index if not exists evidence_reviews_report_idx on public.evidence_reviews (report_id);

-- ------------------------------------------------------ urgency_assessments ----
create table if not exists public.urgency_assessments (
  assessment_id uuid primary key default gen_random_uuid(),
  report_id     uuid not null unique references public.reports (report_id) on delete restrict,
  reviewer_id   uuid not null references public.profiles (user_id) on delete restrict,
  level         text not null check (level in ('critical', 'high', 'medium', 'low')),
  score         integer not null check (score between 1 and 4),
  due_at        timestamptz not null,
  note          text check (note is null or char_length(note) <= 1000),
  created_at    timestamptz not null default now()
);

-- ------------------------------------------------------------ case_updates ----
create table if not exists public.case_updates (
  update_id     uuid primary key default gen_random_uuid(),
  report_id     uuid not null references public.reports (report_id) on delete restrict,
  officer_id    uuid not null references public.profiles (user_id) on delete restrict,
  stage         text not null check (stage in ('forwarded', 'investigating', 'charge_sheet', 'trial', 'closed')),
  expected_days integer check (expected_days is null or expected_days between 0 and 3650),
  details       text check (details is null or char_length(details) <= 2000),
  created_at    timestamptz not null default now()
);
create index if not exists case_updates_report_idx on public.case_updates (report_id, created_at);

-- ----------------------------------------------------------------- appeals ----
create table if not exists public.appeals (
  appeal_id  uuid primary key default gen_random_uuid(),
  report_id  uuid not null unique references public.reports (report_id) on delete restrict,  -- one appeal per report (FR-17)
  reason     text not null check (char_length(btrim(reason)) >= 10),
  status     text not null default 're_review' check (status in ('re_review', 'overturned', 'upheld')),
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------------- audit_logs ----
-- 002 adds prev_hash / row_hash, the hash-chain triggers and the append-only rules.
-- actor_id is NULL only for actions the system itself takes (for example applying a strike).
create table if not exists public.audit_logs (
  log_id     bigint generated always as identity primary key,
  actor_id   uuid references public.profiles (user_id) on delete restrict,
  action     text not null,
  entity     text not null,
  entity_id  uuid,
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_created_idx on public.audit_logs (created_at desc);

-- ---------------------------------------------------------------- lock down ----
alter table public.profiles            enable row level security;
alter table public.locations           enable row level security;
alter table public.reports             enable row level security;
alter table public.evidence            enable row level security;
alter table public.evidence_reviews    enable row level security;
alter table public.urgency_assessments enable row level security;
alter table public.case_updates        enable row level security;
alter table public.appeals             enable row level security;
alter table public.audit_logs          enable row level security;
