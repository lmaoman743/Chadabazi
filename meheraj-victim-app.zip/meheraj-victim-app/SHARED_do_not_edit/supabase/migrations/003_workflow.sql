-- =============================================================================
-- 003_workflow.sql   (owner: Md Abir Molla - case lifecycle, assignment, strikes, rate limit)
--
-- Runs AFTER 001 (tables) and 002 (security). Everything that changes a case goes
-- through ONE of the functions below. They are SECURITY DEFINER and executable by the
-- server (service_role) only, because they must:
--   * work on rows the caller cannot read (victim_id is hidden from staff),
--   * write the audit line in the SAME transaction as the action (no action without a log line),
--   * never return victim_id to a staff caller.
-- The Next.js routes check the caller's role first (requireRole), then call these.
--
-- Rules implemented (proposal FR-12, FR-13, FR-14, FR-17, FR-18, FR-21):
--   * 2 random Evidence Reviewers per report. Both valid -> "valid". Both rejected -> "rejected".
--     Split decision -> one extra random reviewer is added and the majority decides.
--   * Appeal (once): new random reviewers (preferring people who have not seen the case) re-review it.
--   * Strike only when EVERY rejecting reviewer chose "suspected_false" and the rejection stands.
--     Strike 1 = warning, strike 2 = 30-day suspension, strike 3 = suspended + flagged for an
--     admin to decide a permanent block (the block itself is done by web/lib/security/blocking.ts).
--   * A successful appeal reverses the strike.
--   * At most 3 reports per 24 hours per account (database trigger).
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. New tables
-- ---------------------------------------------------------------------------
alter table public.reports add column if not exists strike_applied boolean not null default false;

create table if not exists public.review_assignments (
  report_id   uuid not null references public.reports (report_id) on delete restrict,
  reviewer_id uuid not null references public.profiles (user_id) on delete restrict,
  round       integer not null default 1,
  assigned_at timestamptz not null default now(),
  primary key (report_id, reviewer_id, round)
);

-- Flags raised by the strike policy for a human decision. No report_id on purpose:
-- the admin decides from the pseudonym and the rejection reasons, and cannot link
-- a flag to the content of a specific report.
create table if not exists public.abuse_flags (
  flag_id       uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles (user_id) on delete restrict,
  reason        text not null default 'third_strike',
  status        text not null default 'pending' check (status in ('pending', 'blocked', 'dismissed')),
  created_at    timestamptz not null default now(),
  resolved_by   uuid references public.profiles (user_id),
  resolved_at   timestamptz
);

alter table public.review_assignments enable row level security;
alter table public.abuse_flags        enable row level security;
revoke all on public.review_assignments, public.abuse_flags from anon, authenticated;  -- server only

-- ---------------------------------------------------------------------------
-- 2. Small helpers
-- ---------------------------------------------------------------------------
create or replace function public.wf_fail(p_code text)
returns void
language plpgsql set search_path = ''
as $$
begin
  raise exception using errcode = 'P0001', message = p_code;
end;
$$;

create or replace function public.audit_append(p_actor uuid, p_action text, p_entity text, p_entity_id uuid)
returns void
language sql security definer set search_path = ''
as $$
  insert into public.audit_logs (actor_id, action, entity, entity_id) values (p_actor, p_action, p_entity, p_entity_id);
$$;

-- "Dhaka > Gazipur > Kaliakair" in English or Bangla. Readable by signed-in users (locations are public data).
create or replace function public.location_path(p_id integer, p_lang text default 'en')
returns text
language sql stable security definer set search_path = ''
as $$
  with recursive up as (
    select l.location_id, l.parent_id, l.name_en, l.name_bn, 1 as depth
      from public.locations l where l.location_id = p_id
    union all
    select l.location_id, l.parent_id, l.name_en, l.name_bn, up.depth + 1
      from public.locations l join up on l.location_id = up.parent_id
  )
  select string_agg(case when p_lang = 'bn' then name_bn else name_en end, ' > ' order by depth desc) from up;
$$;
revoke execute on function public.location_path(integer, text) from public, anon;
grant  execute on function public.location_path(integer, text) to authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 3. At most three reports per 24 hours (FR-08 / TC-06)
-- ---------------------------------------------------------------------------
create or replace function public.reports_daily_limit()
returns trigger
language plpgsql security definer set search_path = ''
as $$
begin
  if (select count(*) from public.reports r
       where r.victim_id = new.victim_id and r.created_at > now() - interval '24 hours') >= 3 then
    perform public.wf_fail('daily_report_limit');
  end if;
  return new;
end;
$$;
drop trigger if exists reports_daily_limit_trg on public.reports;
create trigger reports_daily_limit_trg before insert on public.reports
  for each row execute function public.reports_daily_limit();

-- ---------------------------------------------------------------------------
-- 4. Reviewer assignment (FR-12)
-- ---------------------------------------------------------------------------
-- Adds up to p_count random active reviewers for a round. People who already saw
-- this report in an earlier round are chosen last (they are used only if nobody else exists).
create or replace function public.assign_reviewers(p_report uuid, p_count integer, p_round integer)
returns integer
language plpgsql security definer set search_path = ''
as $$
declare
  v_added integer;
begin
  with picked as (
    select p.user_id
      from public.profiles p
     where p.role = 'evidence_reviewer' and p.status = 'active'
       and not exists (select 1 from public.review_assignments a
                        where a.report_id = p_report and a.reviewer_id = p.user_id and a.round = p_round)
     order by exists (select 1 from public.review_assignments a2
                       where a2.report_id = p_report and a2.reviewer_id = p.user_id) asc,
              random()
     limit p_count
  ), ins as (
    insert into public.review_assignments (report_id, reviewer_id, round)
    select p_report, user_id, p_round from picked
    returning 1
  )
  select count(*) into v_added from ins;
  return v_added;
end;
$$;

-- Gives every "submitted" report its two reviewers and moves it to "under_review".
-- Safe to call as often as you like (the reviewer queue calls it before listing).
create or replace function public.assign_pending_reports()
returns integer
language plpgsql security definer set search_path = ''
as $$
declare
  r        record;
  v_have   integer;
  v_moved  integer := 0;
begin
  for r in select report_id from public.reports where status = 'submitted' for update skip locked loop
    select count(*) into v_have from public.review_assignments a where a.report_id = r.report_id and a.round = 1;
    if v_have < 2 then
      perform public.assign_reviewers(r.report_id, 2 - v_have, 1);
      select count(*) into v_have from public.review_assignments a where a.report_id = r.report_id and a.round = 1;
    end if;
    if v_have >= 2 then
      update public.reports set status = 'under_review' where report_id = r.report_id;
      v_moved := v_moved + 1;
    end if;
  end loop;
  return v_moved;
end;
$$;

-- Victim presses "Submit": draft -> submitted (needs at least one evidence file) -> reviewers assigned.
create or replace function public.finalize_report(p_victim uuid, p_report uuid)
returns text
language plpgsql security definer set search_path = ''
as $$
declare
  v_status text;
begin
  select r.status into v_status from public.reports r
   where r.report_id = p_report and r.victim_id = p_victim for update;
  if not found then perform public.wf_fail('report_not_found'); end if;
  if v_status <> 'draft' then perform public.wf_fail('report_not_draft'); end if;
  if not exists (select 1 from public.evidence e where e.report_id = p_report) then
    perform public.wf_fail('evidence_required');
  end if;

  update public.reports set status = 'submitted' where report_id = p_report;
  perform public.assign_pending_reports();
  select r.status into v_status from public.reports r where r.report_id = p_report;
  return v_status;
end;
$$;

-- ---------------------------------------------------------------------------
-- 5. Strike policy (FR-21)
-- ---------------------------------------------------------------------------
create or replace function public.apply_strike(p_report uuid)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_user    uuid;
  v_applied boolean;
  v_count   integer;
begin
  select r.victim_id, r.strike_applied into v_user, v_applied from public.reports r where r.report_id = p_report;
  if v_applied then return; end if;  -- never count the same report twice

  update public.reports set strike_applied = true where report_id = p_report;
  update public.profiles set strike_count = strike_count + 1 where user_id = v_user returning strike_count into v_count;

  if v_count = 2 then
    update public.profiles set status = 'suspended', suspended_until = now() + interval '30 days'
     where user_id = v_user and status = 'active';
  elsif v_count >= 3 then
    update public.profiles set status = 'suspended', suspended_until = null
     where user_id = v_user and status = 'active';
    if not exists (select 1 from public.abuse_flags f where f.user_id = v_user and f.status = 'pending') then
      insert into public.abuse_flags (user_id) values (v_user);
    end if;
  end if;
  -- entity_id stays NULL on purpose: the admin reads the audit log and must not learn which account owns which report.
  perform public.audit_append(null, 'strike.apply', 'profiles', null);
end;
$$;

create or replace function public.reverse_strike(p_report uuid)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_user    uuid;
  v_applied boolean;
  v_count   integer;
begin
  select r.victim_id, r.strike_applied into v_user, v_applied from public.reports r where r.report_id = p_report;
  if not coalesce(v_applied, false) then return; end if;

  update public.reports set strike_applied = false where report_id = p_report;
  update public.profiles set strike_count = greatest(strike_count - 1, 0) where user_id = v_user returning strike_count into v_count;

  if v_count < 3 then
    update public.abuse_flags set status = 'dismissed', resolved_at = now() where user_id = v_user and status = 'pending';
    update public.profiles
       set status          = case when v_count >= 2 then 'suspended' else 'active' end,
           suspended_until = case when v_count >= 2 then coalesce(suspended_until, now() + interval '30 days') else null end
     where user_id = v_user and status = 'suspended';
  end if;
  perform public.audit_append(null, 'strike.reverse', 'profiles', null);
end;
$$;

-- Ends 30-day suspensions whose time is over. The web app calls this at sign-in; you can also
-- schedule it (pg_cron) if your Supabase plan has it.
create or replace function public.lift_expired_suspensions(p_user uuid default null)
returns void
language sql security definer set search_path = ''
as $$
  update public.profiles
     set status = 'active', suspended_until = null
   where status = 'suspended' and suspended_until is not null and suspended_until <= now()
     and (p_user is null or user_id = p_user);
$$;

-- ---------------------------------------------------------------------------
-- 6. Evidence review (FR-13) and how two or three decisions become one result
-- ---------------------------------------------------------------------------
create or replace function public.resolve_reviews(p_report uuid, p_round integer)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_valid     integer;
  v_rejected  integer;
  v_rej_other integer;  -- rejections whose category is NOT suspected_false
begin
  select count(*) filter (where decision = 'valid'),
         count(*) filter (where decision = 'rejected'),
         count(*) filter (where decision = 'rejected' and rejection_category <> 'suspected_false')
    into v_valid, v_rejected, v_rej_other
    from public.evidence_reviews where report_id = p_report and round = p_round;

  if v_valid + v_rejected < 2 then return; end if;          -- still waiting for the second reviewer
  if v_valid = v_rejected then                              -- 1 : 1 -> ask one more reviewer
    if v_valid + v_rejected = 2 then perform public.assign_reviewers(p_report, 1, p_round); end if;
    return;
  end if;

  if v_valid > v_rejected then
    update public.reports set status = 'valid' where report_id = p_report;
    update public.appeals set status = 'overturned' where report_id = p_report and status = 're_review';
    perform public.reverse_strike(p_report);
  else
    update public.reports set status = 'rejected' where report_id = p_report;
    update public.appeals set status = 'upheld' where report_id = p_report and status = 're_review';
    if v_rej_other = 0 then perform public.apply_strike(p_report); end if;
  end if;
end;
$$;

create or replace function public.submit_evidence_review(
  p_reviewer uuid, p_report uuid, p_decision text, p_category text, p_reason text, p_checklist jsonb)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_status text;
  v_round  integer;
begin
  if p_decision not in ('valid', 'rejected') then perform public.wf_fail('invalid_decision'); end if;

  select r.status into v_status from public.reports r where r.report_id = p_report for update;
  if not found or v_status <> 'under_review' then perform public.wf_fail('report_not_under_review'); end if;

  -- The reviewer must be assigned in the CURRENT round of this report.
  select max(a.round) into v_round from public.review_assignments a where a.report_id = p_report;
  if not exists (select 1 from public.review_assignments a
                  where a.report_id = p_report and a.reviewer_id = p_reviewer and a.round = v_round) then
    perform public.wf_fail('not_assigned');
  end if;
  if exists (select 1 from public.evidence_reviews er
              where er.report_id = p_report and er.reviewer_id = p_reviewer and er.round = v_round) then
    perform public.wf_fail('already_reviewed');
  end if;

  if jsonb_typeof(p_checklist) is distinct from 'object' then perform public.wf_fail('checklist_required'); end if;
  if p_decision = 'valid' and exists (select 1 from jsonb_each(p_checklist) e where e.value <> 'true'::jsonb) then
    perform public.wf_fail('checklist_failed');
  end if;
  if p_decision = 'rejected' and (p_category is null or char_length(btrim(coalesce(p_reason, ''))) < 10) then
    perform public.wf_fail('reason_required');  -- TC-08
  end if;

  insert into public.evidence_reviews (report_id, reviewer_id, round, decision, rejection_category, reason, checklist)
  values (p_report, p_reviewer, v_round, p_decision,
          case when p_decision = 'rejected' then p_category end,
          case when p_decision = 'rejected' then btrim(p_reason) end,
          p_checklist);

  perform public.audit_append(p_reviewer, case when p_decision = 'valid' then 'evidence.accept' else 'evidence.reject' end, 'reports', p_report);
  perform public.resolve_reviews(p_report, v_round);
end;
$$;

-- ---------------------------------------------------------------------------
-- 7. Appeal (FR-17): once per report, only for a rejected report, new reviewers
-- ---------------------------------------------------------------------------
create or replace function public.submit_appeal(p_victim uuid, p_report uuid, p_reason text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_status text;
  v_round  integer;
begin
  select r.status into v_status from public.reports r where r.report_id = p_report and r.victim_id = p_victim for update;
  if not found then perform public.wf_fail('report_not_found'); end if;
  if v_status <> 'rejected' then perform public.wf_fail('not_rejected'); end if;
  if exists (select 1 from public.appeals a where a.report_id = p_report) then perform public.wf_fail('already_appealed'); end if;
  if char_length(btrim(coalesce(p_reason, ''))) < 10 then perform public.wf_fail('reason_required'); end if;

  select coalesce(max(a.round), 1) + 1 into v_round from public.review_assignments a where a.report_id = p_report;
  insert into public.appeals (report_id, reason) values (p_report, btrim(p_reason));
  perform public.assign_reviewers(p_report, 2, v_round);
  -- Raising rolls back the appeal row too, so the victim can try again later.
  if (select count(*) from public.review_assignments a where a.report_id = p_report and a.round = v_round) < 2 then
    perform public.wf_fail('no_reviewers_available');
  end if;
  update public.reports set status = 'under_review' where report_id = p_report;
  -- No audit line here: an audit line would tie this report to the victim's account.
end;
$$;

-- ---------------------------------------------------------------------------
-- 8. Urgency review (FR-14)
-- ---------------------------------------------------------------------------
create or replace function public.submit_urgency(p_reviewer uuid, p_report uuid, p_level text, p_note text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_status text;
  v_fast   boolean;
begin
  if p_level not in ('critical', 'high', 'medium', 'low') then perform public.wf_fail('invalid_level'); end if;
  select r.status, r.fast_track into v_status, v_fast from public.reports r where r.report_id = p_report for update;
  if not found then perform public.wf_fail('report_not_found'); end if;
  -- Normal cases only after the evidence is valid; fast-track cases may be ranked while still in review.
  if not (v_status = 'valid' or (v_fast and v_status in ('submitted', 'under_review'))) then
    perform public.wf_fail('report_not_assessable');
  end if;
  if exists (select 1 from public.urgency_assessments u where u.report_id = p_report) then
    perform public.wf_fail('already_assessed');
  end if;

  insert into public.urgency_assessments (report_id, reviewer_id, level, score, due_at, note)
  values (p_report, p_reviewer, p_level,
          case p_level when 'critical' then 4 when 'high' then 3 when 'medium' then 2 else 1 end,
          now() + case p_level when 'critical' then interval '1 day' when 'high' then interval '3 days'
                               when 'medium' then interval '7 days' else interval '14 days' end,
          nullif(btrim(coalesce(p_note, '')), ''));
  perform public.audit_append(p_reviewer, 'urgency.assess', 'reports', p_report);
end;
$$;

-- ---------------------------------------------------------------------------
-- 9. Police / case updates (FR-16, FR-18)
--    forwarded: valid + assessed -> forwarded_to_police
--    investigating / charge_sheet / trial: -> under_investigation
--    closed: -> closed (details = outcome)
-- ---------------------------------------------------------------------------
create or replace function public.add_case_update(p_officer uuid, p_report uuid, p_stage text, p_expected_days integer, p_details text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_status text;
  v_new    text;
begin
  if p_stage not in ('forwarded', 'investigating', 'charge_sheet', 'trial', 'closed') then
    perform public.wf_fail('invalid_stage');
  end if;
  select r.status into v_status from public.reports r where r.report_id = p_report for update;
  if not found then perform public.wf_fail('report_not_found'); end if;

  if p_stage = 'forwarded' then
    if v_status <> 'valid' or not exists (select 1 from public.urgency_assessments u where u.report_id = p_report) then
      perform public.wf_fail('not_ready_to_forward');
    end if;
    v_new := 'forwarded_to_police';
  else
    if v_status not in ('forwarded_to_police', 'under_investigation') then perform public.wf_fail('not_forwarded'); end if;
    v_new := case when p_stage = 'closed' then 'closed' else 'under_investigation' end;
  end if;

  insert into public.case_updates (report_id, officer_id, stage, expected_days, details)
  values (p_report, p_officer, p_stage, p_expected_days, nullif(btrim(coalesce(p_details, '')), ''));
  update public.reports set status = v_new where report_id = p_report;
  perform public.audit_append(p_officer, case when p_stage = 'forwarded' then 'case.forward' else 'case.update' end, 'reports', p_report);
end;
$$;

-- ---------------------------------------------------------------------------
-- 10. Only the server may call these
-- ---------------------------------------------------------------------------
do $$
declare
  f record;
begin
  for f in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname = any (array['wf_fail', 'audit_append', 'assign_reviewers', 'assign_pending_reports', 'finalize_report',
                                   'apply_strike', 'reverse_strike', 'lift_expired_suspensions', 'resolve_reviews',
                                   'submit_evidence_review', 'submit_appeal', 'submit_urgency', 'add_case_update'])
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- 11. Tighten what 002 allowed
--     002 let reviewers/officers/victims INSERT directly. That would skip the audit line, the
--     assignment check and the lifecycle rules, so inserts now happen only through the functions above.
-- ---------------------------------------------------------------------------
revoke insert on public.evidence_reviews    from authenticated;
revoke insert on public.urgency_assessments from authenticated;
revoke insert on public.case_updates        from authenticated;
revoke insert on public.appeals             from authenticated;
drop policy if exists evidence_reviews_insert on public.evidence_reviews;
drop policy if exists urgency_insert          on public.urgency_assessments;
drop policy if exists case_updates_officer_insert on public.case_updates;
drop policy if exists appeals_victim_insert   on public.appeals;

-- ---------------------------------------------------------------------------
-- 12. Staff views: each role sees only the cases it should work on, never victim_id.
--     (same column list as 002, so CREATE OR REPLACE works)
-- ---------------------------------------------------------------------------
create or replace view public.staff_reports as
select r.report_id, r.location_id, r.chadabazi_type, r.amount_demanded, r.incident_date,
       r.description, r.accused_description, r.fast_track, r.status, r.created_at
from public.reports r
where r.status <> 'draft'
  and (
    -- Evidence Reviewer: only cases assigned to them in the current round that they have not decided yet.
    (public.current_role_name() = 'evidence_reviewer'
      and r.status = 'under_review'
      and exists (select 1 from public.review_assignments a
                   where a.report_id = r.report_id and a.reviewer_id = auth.uid()
                     and a.round = (select max(a2.round) from public.review_assignments a2 where a2.report_id = r.report_id))
      and not exists (select 1 from public.evidence_reviews er
                       where er.report_id = r.report_id and er.reviewer_id = auth.uid()
                         and er.round = (select max(a3.round) from public.review_assignments a3 where a3.report_id = r.report_id)))
    -- Urgency Reviewer: valid cases and fast-track cases that have no urgency level yet.
    or (public.current_role_name() = 'urgency_reviewer'
      and not exists (select 1 from public.urgency_assessments u where u.report_id = r.report_id)
      and (r.status = 'valid' or (r.fast_track and r.status in ('submitted', 'under_review'))))
    -- Case Officer: valid cases that already have an urgency level, and everything after forwarding.
    or (public.current_role_name() = 'case_officer'
      and r.status in ('valid', 'forwarded_to_police', 'under_investigation', 'closed')
      and (r.status <> 'valid' or exists (select 1 from public.urgency_assessments u where u.report_id = r.report_id)))
  );

-- A victim sees rejection reasons only once the report is really rejected (not one reviewer's opinion
-- in a split decision), and never who decided.
drop view if exists public.victim_rejections;
create view public.victim_rejections as
select er.report_id, er.round, er.rejection_category, er.reason
from public.evidence_reviews er
join public.reports r on r.report_id = er.report_id
where er.decision = 'rejected'
  and r.status = 'rejected'
  and r.victim_id = auth.uid()
  and public.current_role_name() = 'victim';

revoke all on public.staff_reports, public.victim_rejections from anon, authenticated;
grant select on public.staff_reports, public.victim_rejections to authenticated;

-- Evidence rows (paths, hashes) are visible to staff only for cases their view shows them.
drop policy if exists evidence_staff_select on public.evidence;
create policy evidence_staff_select on public.evidence for select to authenticated
  using (exists (select 1 from public.staff_reports s where s.report_id = evidence.report_id));
