# Meheraj Hossen Ovi: victim-facing frontend

## Your files
```
web/app/page.tsx                        landing page
web/app/login                           email -> one-time code (calls Arafat's /api/auth/register and /verify)
web/app/account-unavailable             suspended / blocked message
web/app/victim/page.tsx                 "Allegations You Have Made" (FR-15)
web/app/victim/report/new               report form + cascading location list (FR-05..07)
web/app/victim/reports/[reportId]       detail: evidence upload, submit, rejection reasons, appeal, police progress (FR-16, FR-17)
web/app/api/victim/**                   list/create/get report, submit, appeal
web/components/{LocationSelector,EvidenceUploader,CaseProgressPanel}.tsx
web/lib/victim/reports.ts               loads a victim's reports (RLS limits it to their own)
web/lib/case/progress.ts                days since filing / expected days remaining
```
## Depends on
Arafat: sign-in routes, `requireRole`, processing service (`NEXT_PUBLIC_PROCESSING_URL`, upload to `/v1/reports/:id/evidence`).
Abir: `finalize_report`, `submit_appeal` SQL functions, `location_path`, the 3-per-day trigger.
Nabila: text in `lib/i18n`, location rows (`004_locations_seed.sql`).

## Flow to demo
Sign up with a real email -> New report (district or deeper) -> add a photo -> Submit -> status "Under review" -> after review see Valid / Rejected with reasons -> appeal once -> police progress.
Rules: at most 3 reports/24 h; drafts are invisible to staff; submit needs at least one file.

## Not verified
Written but never run: no Next.js build, no `npm run typecheck`, no pages opened in a browser, SQL migrations not executed on a real database. Expect small fixes on first run.
Arafat's `web/lib/security/*` and `/api/auth/*` are NOT in this zip; you need them (and the edited `http.ts` with `handleParams`) from the full project.
`SHARED_do_not_edit/` holds files owned by other members that your part imports. Copy them over `web/` only if you do not have the full project.
