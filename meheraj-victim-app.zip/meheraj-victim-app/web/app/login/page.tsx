'use client';
import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { api, errorText } from '@/lib/client/api';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useI18n } from '@/components/I18nProvider';
import { btn, btnGhost, card, errorBox, input, label, noteBox } from '@/components/ui';

/** Victim sign-up / sign-in: email, then the one-time code (FR-01, FR-02). */
export default function LoginPage() {
  const { t, has } = useI18n();
  const router = useRouter();
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function sendCode(e?: FormEvent) {
    e?.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api('/api/auth/register', { body: { email } });
      setStep('code');
    } catch (err) {
      setError(errorText(err, t, has));
    } finally {
      setBusy(false);
    }
  }

  async function verify(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api('/api/auth/verify', { body: { email, token } });
      router.replace('/victim');
      router.refresh();
    } catch (err) {
      setError(errorText(err, t, has));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto max-w-md px-4 py-10">
      <div className="mb-6 flex justify-end">
        <LanguageSwitcher />
      </div>
      <h1 className="mb-4 text-2xl font-bold text-blue-900">{t('login.title')}</h1>

      <div className={`${card} space-y-4`}>
        <p className={noteBox}>{t('login.anonymousNote')}</p>

        {step === 'email' ? (
          <form onSubmit={sendCode} className="space-y-4">
            <div>
              <label htmlFor="email" className={label}>
                {t('login.email')}
              </label>
              <input id="email" type="email" required autoComplete="email" className={input} value={email} onChange={(e) => setEmail(e.target.value)} />
              <p className="mt-1 text-xs text-slate-500">{t('login.emailHelp')}</p>
            </div>
            {error ? <p className={errorBox}>{error}</p> : null}
            <button type="submit" className={btn} disabled={busy || email.length < 5}>
              {busy ? t('common.loading') : t('login.sendCode')}
            </button>
          </form>
        ) : (
          <form onSubmit={verify} className="space-y-4">
            <p className="text-sm text-slate-700">{t('login.codeSent')}</p>
            <div>
              <label htmlFor="token" className={label}>
                {t('login.code')}
              </label>
              <input
                id="token"
                inputMode="numeric"
                autoComplete="one-time-code"
                pattern="\d{6,10}"
                required
                className={input}
                value={token}
                onChange={(e) => setToken(e.target.value.replace(/\D/g, ''))}
              />
            </div>
            {error ? <p className={errorBox}>{error}</p> : null}
            <div className="flex flex-wrap gap-3">
              <button type="submit" className={btn} disabled={busy || token.length < 6}>
                {busy ? t('common.loading') : t('login.verify')}
              </button>
              <button type="button" className={btnGhost} disabled={busy} onClick={() => void sendCode()}>
                {t('login.resend')}
              </button>
              <button type="button" className={btnGhost} onClick={() => { setStep('email'); setToken(''); setError(null); }}>
                {t('login.changeEmail')}
              </button>
            </div>
          </form>
        )}
      </div>
    </main>
  );
}
