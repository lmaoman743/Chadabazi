'use client';
import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { LocationSelector } from '@/components/LocationSelector';
import { useI18n } from '@/components/I18nProvider';
import { btn, card, errorBox, input, label, noteBox } from '@/components/ui';
import { api, errorText } from '@/lib/client/api';
import { CHADABAZI_TYPES } from '@/lib/workflow/constants';

const MIN_DEPTH = 2; // at least Division + District

/** New report form (FR-05, FR-06, FR-07). It saves a draft; evidence is added on the next screen. */
export default function NewReport() {
  const { t, has } = useI18n();
  const router = useRouter();
  const [locationId, setLocationId] = useState<number | null>(null);
  const [depth, setDepth] = useState(0);
  const [type, setType] = useState<string>(CHADABAZI_TYPES[0]);
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState('');
  const [description, setDescription] = useState('');
  const [accused, setAccused] = useState('');
  const [fastTrack, setFastTrack] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Today's date in the visitor's own time zone (Bangladesh is UTC+6, so UTC would be a day behind early in the morning).
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60_000).toISOString().slice(0, 10);
  const ready = locationId !== null && depth >= MIN_DEPTH && amount !== '' && date !== '' && description.trim().length >= 10;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!ready) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ report_id: string }>('/api/victim/reports', {
        body: {
          location_id: locationId,
          chadabazi_type: type,
          amount_demanded: Number(amount),
          incident_date: date,
          description: description.trim(),
          accused_description: accused.trim(),
          fast_track: fastTrack,
        },
      });
      router.push(`/victim/reports/${res.report_id}`);
    } catch (err) {
      setError(errorText(err, t, has));
      setBusy(false);
    }
  }

  return (
    <>
      <Header nav={[{ href: '/victim', labelKey: 'victim.title' }]} />
      <main className="mx-auto max-w-2xl px-4 py-6">
        <h1 className="mb-4 text-2xl font-bold text-blue-900">{t('form.title')}</h1>
        <form onSubmit={submit} className={`${card} space-y-5`}>
          <p className={noteBox}>{t('form.privacyWarning')}</p>

          <fieldset className="space-y-2">
            <legend className="text-base font-semibold">{t('form.location')}</legend>
            <LocationSelector
              onChange={(id, d) => {
                setLocationId(id);
                setDepth(d);
              }}
            />
            {locationId !== null && depth < MIN_DEPTH ? <p className="text-xs text-slate-500">{t('form.locationMin')}</p> : null}
            <p className="text-xs text-slate-500">{t('form.locationHelp')}</p>
          </fieldset>

          <div>
            <label htmlFor="type" className={label}>
              {t('form.type')}
            </label>
            <select id="type" className={input} value={type} onChange={(e) => setType(e.target.value)}>
              {CHADABAZI_TYPES.map((k) => (
                <option key={k} value={k}>
                  {t(`type.${k}`)}
                </option>
              ))}
            </select>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="amount" className={label}>
                {t('form.amount')}
              </label>
              <input id="amount" type="number" min={0} step="1" required className={input} value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
            <div>
              <label htmlFor="date" className={label}>
                {t('form.date')}
              </label>
              <input id="date" type="date" max={today} required className={input} value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
          </div>

          <div>
            <label htmlFor="desc" className={label}>
              {t('form.description')}
            </label>
            <textarea id="desc" rows={6} maxLength={2000} required className={input} value={description} onChange={(e) => setDescription(e.target.value)} />
            <p className="mt-1 text-xs text-slate-500">{t('form.descriptionHelp')}</p>
          </div>

          <div>
            <label htmlFor="accused" className={label}>
              {t('form.accused')} <span className="font-normal text-slate-500">({t('common.optional')})</span>
            </label>
            <textarea id="accused" rows={3} maxLength={500} className={input} value={accused} onChange={(e) => setAccused(e.target.value)} />
          </div>

          <label className="flex items-start gap-3 rounded-md border border-slate-200 p-3 text-sm">
            <input type="checkbox" className="mt-1" checked={fastTrack} onChange={(e) => setFastTrack(e.target.checked)} />
            <span>
              <span className="font-semibold">{t('form.fastTrack')}</span>
              <span className="block text-slate-600">{t('form.fastTrackHelp')}</span>
            </span>
          </label>

          {error ? <p className={errorBox}>{error}</p> : null}
          <button type="submit" className={btn} disabled={!ready || busy}>
            {busy ? t('common.loading') : t('form.saveContinue')}
          </button>
        </form>
      </main>
    </>
  );
}
