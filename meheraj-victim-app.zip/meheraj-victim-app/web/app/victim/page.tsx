'use client';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { StatusBadge } from '@/components/StatusBadge';
import { useI18n } from '@/components/I18nProvider';
import { btn, card, errorBox, noteBox } from '@/components/ui';
import { errorText } from '@/lib/client/api';
import { formatDate } from '@/lib/client/format';
import { useApi } from '@/lib/client/useApi';
import type { VictimReport } from '@/lib/victim/reports';

interface Dashboard {
  pseudonym_id: string;
  strike_count: number;
  reports: VictimReport[];
}

/** "Allegations You Have Made" (FR-15): every report with its current status. */
export default function VictimHome() {
  const { t, has, lang } = useI18n();
  const { data, error, loading } = useApi<Dashboard>('/api/victim/reports');

  return (
    <>
      <Header showId={data?.pseudonym_id} />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h1 className="text-2xl font-bold text-blue-900">{t('victim.title')}</h1>
          <Link href="/victim/report/new" className={btn}>
            {t('victim.newReport')}
          </Link>
        </div>

        {data && data.strike_count > 0 ? <p className={`${noteBox} mb-4`}>{t('victim.strikeWarning', { n: data.strike_count })}</p> : null}
        {loading ? <p className="text-slate-600">{t('common.loading')}</p> : null}
        {error ? <p className={errorBox}>{errorText(error, t, has)}</p> : null}
        {data && data.reports.length === 0 ? <p className={card}>{t('victim.empty')}</p> : null}

        <ul className="space-y-3">
          {data?.reports.map((r) => (
            <li key={r.report_id}>
              <Link href={`/victim/reports/${r.report_id}`} className={`${card} block hover:border-blue-400`}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">{t(`type.${r.chadabazi_type}`)}</span>
                  <StatusBadge status={r.status} />
                </div>
                <p className="mt-1 text-sm text-slate-600">
                  {(lang === 'bn' ? r.location_bn : r.location_en) ?? ''} · {formatDate(r.incident_date, lang)}
                </p>
                {r.progress ? (
                  <p className="mt-2 text-sm text-slate-800">
                    {t(`stage.${r.progress.stage}`)} · {t('case.daysSinceShort', { n: r.progress.daysSinceFiling })}
                    {r.progress.expectedDaysRemaining !== null && !r.progress.closed
                      ? ` · ${r.progress.overdue ? t('case.overdue') : t('case.remainingShort', { n: r.progress.expectedDaysRemaining })}`
                      : ''}
                  </p>
                ) : null}
                {r.status === 'rejected' ? <p className="mt-2 text-sm text-red-700">{t('victim.rejectedHint')}</p> : null}
                {r.status === 'draft' ? <p className="mt-2 text-sm text-slate-700">{t('victim.draftHint')}</p> : null}
              </Link>
            </li>
          ))}
        </ul>
      </main>
    </>
  );
}
