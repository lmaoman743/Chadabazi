'use client';
import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { CaseProgressPanel } from '@/components/CaseProgressPanel';
import { EvidenceUploader } from '@/components/EvidenceUploader';
import { Header } from '@/components/Header';
import { StatusBadge } from '@/components/StatusBadge';
import { useI18n } from '@/components/I18nProvider';
import { btn, card, errorBox, input, label, noteBox } from '@/components/ui';
import { api, errorText } from '@/lib/client/api';
import { formatDate, formatMoney } from '@/lib/client/format';
import { useApi } from '@/lib/client/useApi';
import type { VictimReport } from '@/lib/victim/reports';

/** One report: status, rejection reasons + appeal (FR-17), police progress (FR-16), evidence and submit. */
export default function ReportDetail() {
  const { reportId } = useParams<{ reportId: string }>();
  const { t, has, lang } = useI18n();
  const { data: r, error, loading, reload } = useApi<VictimReport>(`/api/victim/reports/${reportId}`);
  const [actionError, setActionError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [appealReason, setAppealReason] = useState('');

  async function submitReport() {
    setBusy(true);
    setActionError(null);
    try {
      await api(`/api/victim/reports/${reportId}/submit`, { method: 'POST', body: {} });
      await reload();
    } catch (e) {
      setActionError(errorText(e, t, has));
    } finally {
      setBusy(false);
    }
  }

  async function appeal(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setActionError(null);
    try {
      await api(`/api/victim/reports/${reportId}/appeal`, { body: { reason: appealReason } });
      setAppealReason('');
      await reload();
    } catch (err) {
      setActionError(errorText(err, t, has));
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Header nav={[{ href: '/victim', labelKey: 'victim.title' }]} />
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-6">
        <Link href="/victim" className="text-sm text-blue-800 underline">
          ← {t('common.back')}
        </Link>
        {loading && !r ? <p className="text-slate-600">{t('common.loading')}</p> : null}
        {error ? <p className={errorBox}>{errorText(error, t, has)}</p> : null}

        {r ? (
          <>
            <section className={card}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h1 className="text-xl font-bold text-blue-900">{t(`type.${r.chadabazi_type}`)}</h1>
                <StatusBadge status={r.status} />
              </div>
              <dl className="mt-3 grid gap-3 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-xs uppercase text-slate-500">{t('form.location')}</dt>
                  <dd>{(lang === 'bn' ? r.location_bn : r.location_en) ?? '-'}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-slate-500">{t('form.date')}</dt>
                  <dd>{formatDate(r.incident_date, lang)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-slate-500">{t('form.amount')}</dt>
                  <dd>{formatMoney(r.amount_demanded, lang)}</dd>
                </div>
              </dl>
              <p className="mt-3 whitespace-pre-wrap text-sm text-slate-800">{r.description}</p>
              {r.fast_track ? <p className="mt-2 text-xs font-semibold text-red-700">{t('form.fastTrack')}</p> : null}
            </section>

            {/* Status explanation, so the victim always knows what happens next. */}
            <p className={noteBox}>{t(`next.${r.status}`)}</p>

            {r.status === 'draft' ? (
              <section className={`${card} space-y-3`}>
                <h2 className="text-lg font-semibold">{t('detail.evidence')}</h2>
                <EvidenceUploader reportId={r.report_id} items={r.evidence} onChanged={() => void reload()} />
                {actionError ? <p className={errorBox}>{actionError}</p> : null}
                <button type="button" className={btn} disabled={busy || r.evidence.length === 0} onClick={() => void submitReport()}>
                  {busy ? t('common.loading') : t('detail.submitReport')}
                </button>
                {r.evidence.length === 0 ? <p className="text-xs text-slate-500">{t('detail.needEvidence')}</p> : null}
              </section>
            ) : (
              <section className={card}>
                <h2 className="mb-2 text-lg font-semibold">{t('detail.evidence')}</h2>
                {r.evidence.length === 0 ? (
                  <p className="text-sm text-slate-600">{t('upload.none')}</p>
                ) : (
                  <ul className="space-y-1 text-sm">
                    {r.evidence.map((e) => (
                      <li key={e.evidence_id}>
                        {t(`file.${e.file_type}`)} · <span className="font-mono text-xs text-slate-500">SHA-256 {e.sha256.slice(0, 12)}…</span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            )}

            {r.status === 'rejected' ? (
              <section className={`${card} space-y-3`}>
                <h2 className="text-lg font-semibold text-red-800">{t('detail.rejectionTitle')}</h2>
                <ul className="space-y-2 text-sm">
                  {r.rejections.map((x, i) => (
                    <li key={i} className="rounded-md bg-red-50 p-3">
                      <p className="font-semibold">{t(`category.${x.rejection_category}`)}</p>
                      <p className="mt-1 whitespace-pre-wrap text-slate-800">{x.reason}</p>
                    </li>
                  ))}
                </ul>
                {r.appeal ? (
                  <p className={noteBox}>{t('detail.appealDone')}</p>
                ) : (
                  <form onSubmit={appeal} className="space-y-2">
                    <label htmlFor="appeal" className={label}>
                      {t('detail.appealLabel')}
                    </label>
                    <textarea id="appeal" rows={4} maxLength={1000} required className={input} value={appealReason} onChange={(e) => setAppealReason(e.target.value)} />
                    <p className="text-xs text-slate-500">{t('detail.appealOnce')}</p>
                    {actionError ? <p className={errorBox}>{actionError}</p> : null}
                    <button type="submit" className={btn} disabled={busy || appealReason.trim().length < 10}>
                      {busy ? t('common.loading') : t('detail.appealSend')}
                    </button>
                  </form>
                )}
              </section>
            ) : null}

            {r.appeal && r.status !== 'rejected' ? (
              <p className={noteBox}>{t(`appeal.${r.appeal.status}`)}</p>
            ) : null}

            {r.progress ? <CaseProgressPanel progress={r.progress} updates={r.updates} /> : null}
          </>
        ) : null}
      </main>
    </>
  );
}
