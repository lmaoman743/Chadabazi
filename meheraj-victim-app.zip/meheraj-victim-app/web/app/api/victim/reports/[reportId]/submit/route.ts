import { createAdminClient } from '@/lib/supabase/admin';
import { handleParams, HttpError, json } from '@/lib/security/http';
import { requireRole } from '@/lib/security/roles-guard';
import { callRpc } from '@/lib/api/rpc';
import { idSchema } from '@/lib/workflow/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** The victim presses "Submit": draft -> submitted, and two random reviewers are assigned (FR-12). */
export const POST = handleParams<{ reportId: string }>(async (_req, { reportId }) => {
  const { user } = await requireRole(['victim']);
  if (!idSchema.safeParse(reportId).success) throw new HttpError(404, 'report_not_found', 'Report not found.');
  // The function checks that the report belongs to this user and has at least one evidence file.
  const status = await callRpc<string>(createAdminClient(), 'finalize_report', { p_victim: user.id, p_report: reportId });
  return json({ status });
});
