import { createAdminClient } from '@/lib/supabase/admin';
import { enforceRateLimit, handleParams, HttpError, json, readJson } from '@/lib/security/http';
import { requireRole } from '@/lib/security/roles-guard';
import { callRpc } from '@/lib/api/rpc';
import { appealSchema, idSchema } from '@/lib/workflow/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Appeal a rejection, once per report (FR-17). New reviewers look at the case again. */
export const POST = handleParams<{ reportId: string }>(async (req, { reportId }) => {
  const { user } = await requireRole(['victim']);
  enforceRateLimit(`appeal:${user.id}`, 10, 60 * 60_000);
  if (!idSchema.safeParse(reportId).success) throw new HttpError(404, 'report_not_found', 'Report not found.');
  const { reason } = await readJson(req, appealSchema);
  await callRpc(createAdminClient(), 'submit_appeal', { p_victim: user.id, p_report: reportId, p_reason: reason });
  return json({ ok: true });
});
