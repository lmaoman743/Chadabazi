import { handleParams, HttpError, json } from '@/lib/security/http';
import { requireRole } from '@/lib/security/roles-guard';
import { idSchema } from '@/lib/workflow/schemas';
import { loadVictimReports } from '@/lib/victim/reports';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handleParams<{ reportId: string }>(async (_req, { reportId }) => {
  const { supabase } = await requireRole(['victim']);
  if (!idSchema.safeParse(reportId).success) throw new HttpError(404, 'report_not_found', 'Report not found.');
  const [report] = await loadVictimReports(supabase, reportId);
  if (!report) throw new HttpError(404, 'report_not_found', 'Report not found.');
  return json(report);
});
