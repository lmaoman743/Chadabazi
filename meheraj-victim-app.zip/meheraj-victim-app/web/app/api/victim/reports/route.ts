import { enforceRateLimit, handle, HttpError, json, readJson } from '@/lib/security/http';
import { requireRole } from '@/lib/security/roles-guard';
import { mapDbError } from '@/lib/api/rpc';
import { createReportSchema } from '@/lib/workflow/schemas';
import { loadVictimReports } from '@/lib/victim/reports';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** "Allegations You Have Made" (FR-15): the victim's own reports with status, rejection reasons and police progress. */
export const GET = handle(async () => {
  const { supabase, profile } = await requireRole(['victim']);
  const { data: me } = await supabase.from('profiles').select('strike_count, suspended_until').eq('user_id', profile.user_id).maybeSingle();
  const reports = await loadVictimReports(supabase);
  return json({ pseudonym_id: profile.pseudonym_id, strike_count: me?.strike_count ?? 0, reports });
});

/** Creates a DRAFT report (FR-05, FR-06, FR-07). The victim then uploads evidence and presses Submit. */
export const POST = handle(async (req) => {
  const { supabase, user } = await requireRole(['victim']);
  enforceRateLimit(`report-create:${user.id}`, 10, 60 * 60_000);
  const body = await readJson(req, createReportSchema);

  // victim_id is filled in by the database (auth.uid()); status cannot be set by the browser.
  const { data, error } = await supabase
    .from('reports')
    .insert({
      location_id: body.location_id,
      chadabazi_type: body.chadabazi_type,
      amount_demanded: body.amount_demanded,
      incident_date: body.incident_date,
      description: body.description,
      accused_description: body.accused_description ? body.accused_description : null,
      fast_track: body.fast_track,
    })
    .select('report_id')
    .single();
  if (error || !data) {
    if (error?.code === '23503') throw new HttpError(400, 'invalid_location', 'Please choose a valid location.'); // unknown location_id
    throw mapDbError(error?.message); // includes the 3-reports-per-24-hours rule (TC-06)
  }
  return json({ report_id: data.report_id }, { status: 201 });
});
