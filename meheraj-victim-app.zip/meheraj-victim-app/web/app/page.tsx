'use client';
import Link from 'next/link';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useI18n } from '@/components/I18nProvider';
import { btn, btnGhost, card } from '@/components/ui';

export default function Home() {
  const { t } = useI18n();
  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <div className="mb-8 flex justify-end">
        <LanguageSwitcher />
      </div>
      <h1 className="text-3xl font-bold text-blue-900">{t('app.title')}</h1>
      <p className="mt-3 text-lg text-slate-700">{t('home.subtitle')}</p>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link href="/login" className={btn}>
          {t('home.start')}
        </Link>
        <Link href="/victim" className={btnGhost}>
          {t('home.myReports')}
        </Link>
      </div>

      <section className={`${card} mt-8`}>
        <h2 className="text-lg font-semibold">{t('home.howTitle')}</h2>
        <ol className="mt-3 list-decimal space-y-2 pl-5 text-slate-700">
          <li>{t('home.how1')}</li>
          <li>{t('home.how2')}</li>
          <li>{t('home.how3')}</li>
          <li>{t('home.how4')}</li>
        </ol>
      </section>

      <section className={`${card} mt-4`}>
        <h2 className="text-lg font-semibold">{t('home.safetyTitle')}</h2>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-slate-700">
          <li>{t('home.safety1')}</li>
          <li>{t('home.safety2')}</li>
          <li>{t('home.safety3')}</li>
        </ul>
      </section>

      <p className="mt-6 text-sm text-slate-500">{t('home.prototype')}</p>
      <p className="mt-2 text-sm">
        <Link href="/staff/login" className="text-slate-500 underline">
          {t('home.staffLogin')}
        </Link>
      </p>
    </main>
  );
}
