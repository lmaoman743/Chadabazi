'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { createBrowserSupabase } from '@/lib/supabase/client';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useI18n } from '@/components/I18nProvider';
import { card, noteBox } from '@/components/ui';

/** Shown when an account is suspended or blocked (FR-21). The person can read their own profile row only. */
export default function AccountUnavailable() {
  const { t, lang } = useI18n();
  const [info, setInfo] = useState<{ status: string; suspended_until: string | null } | null>(null);
  const client = useRef<ReturnType<typeof createBrowserSupabase> | null>(null);

  useEffect(() => {
    client.current ??= createBrowserSupabase();
    (async () => {
      const { data: auth } = await client.current!.auth.getUser();
      if (!auth.user) return;
      const { data } = await client.current!.from('profiles').select('status, suspended_until').eq('user_id', auth.user.id).maybeSingle();
      if (data) setInfo(data as { status: string; suspended_until: string | null });
    })();
  }, []);

  const until = info?.suspended_until ? new Date(info.suspended_until).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-GB') : null;

  return (
    <main className="mx-auto max-w-md px-4 py-10">
      <div className="mb-6 flex justify-end">
        <LanguageSwitcher />
      </div>
      <div className={`${card} space-y-3`}>
        <h1 className="text-xl font-bold text-blue-900">{t('unavailable.title')}</h1>
        {info?.status === 'suspended' ? (
          <p className={noteBox}>{until ? t('unavailable.suspendedUntil', { date: until }) : t('unavailable.suspendedReview')}</p>
        ) : info?.status === 'blocked' ? (
          <p className={noteBox}>{t('unavailable.blocked')}</p>
        ) : (
          <p className={noteBox}>{t('unavailable.generic')}</p>
        )}
        <Link href="/" className="text-sm text-blue-800 underline">
          {t('common.home')}
        </Link>
      </div>
    </main>
  );
}
