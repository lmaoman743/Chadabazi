// What the victim sees for a case the police are working on (FR-16):
// stage, days since filing, expected days remaining and the latest details.

export interface CaseUpdateLike {
  stage: string;
  expected_days: number | null;
  details: string | null;
  created_at: string;
}

export interface CaseProgress {
  stage: string;
  /** Whole days from the first update (filing with the police) to now, or to the closing update. */
  daysSinceFiling: number;
  /** The most recent estimate of the total duration, if the Case Officer gave one. */
  expectedDaysTotal: number | null;
  expectedDaysRemaining: number | null;
  /** True when the estimate has run out but the case is still open. */
  overdue: boolean;
  closed: boolean;
  details: string | null;
}

const DAY_MS = 86_400_000;

export function computeCaseProgress(updates: CaseUpdateLike[], now: Date = new Date()): CaseProgress | null {
  if (updates.length === 0) return null;
  const sorted = [...updates].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  const first = sorted[0];
  const last = sorted[sorted.length - 1];
  const closed = last.stage === 'closed';

  const end = closed ? new Date(last.created_at) : now;
  const daysSinceFiling = Math.max(0, Math.floor((end.getTime() - new Date(first.created_at).getTime()) / DAY_MS));

  // The latest update that carries an estimate wins.
  const withEstimate = [...sorted].reverse().find((u) => u.expected_days !== null);
  const expectedDaysTotal = withEstimate ? withEstimate.expected_days : null;
  const remaining = expectedDaysTotal === null || closed ? (closed ? 0 : null) : Math.max(0, expectedDaysTotal - daysSinceFiling);

  return {
    stage: last.stage,
    daysSinceFiling,
    expectedDaysTotal,
    expectedDaysRemaining: remaining,
    overdue: !closed && expectedDaysTotal !== null && daysSinceFiling > expectedDaysTotal,
    closed,
    details: last.details,
  };
}
