import type { SupabaseClient } from '@supabase/supabase-js';
import { computeCaseProgress, type CaseProgress } from '@/lib/case/progress';

export interface VictimReport {
  report_id: string;
  chadabazi_type: string;
  amount_demanded: number;
  incident_date: string;
  description: string;
  accused_description: string | null;
  fast_track: boolean;
  status: string;
  created_at: string;
  location_en: string | null;
  location_bn: string | null;
  evidence: { evidence_id: string; file_type: string; sha256: string; uploaded_at: string }[];
  /** Only filled when the report is rejected: category + reason, never who decided (FR-17). */
  rejections: { round: number; rejection_category: string; reason: string }[];
  updates: { stage: string; expected_days: number | null; details: string | null; created_at: string }[];
  progress: CaseProgress | null;
  appeal: { status: string; reason: string; created_at: string } | null;
}

const group = <T extends { report_id: string }>(rows: T[] | null) => {
  const map = new Map<string, T[]>();
  for (const r of rows ?? []) map.set(r.report_id, [...(map.get(r.report_id) ?? []), r]);
  return map;
};

/**
 * Loads the signed-in victim's reports with everything the "Allegations You Have Made" screens show.
 * `supabase` must be the USER's client, so row-level security limits this to their own reports.
 */
export async function loadVictimReports(supabase: SupabaseClient, reportId?: string): Promise<VictimReport[]> {
  let q = supabase
    .from('reports')
    .select('report_id, chadabazi_type, amount_demanded, incident_date, description, accused_description, fast_track, status, location_id, created_at')
    .order('created_at', { ascending: false });
  if (reportId) q = q.eq('report_id', reportId);
  const { data: reports, error } = await q;
  if (error) throw new Error('load_reports_failed');
  if (!reports || reports.length === 0) return [];

  const ids = reports.map((r) => r.report_id as string);
  const [ev, rej, upd, app] = await Promise.all([
    supabase.from('evidence').select('report_id, evidence_id, file_type, sha256, uploaded_at').in('report_id', ids).order('uploaded_at'),
    supabase.from('victim_rejections').select('report_id, round, rejection_category, reason').in('report_id', ids).order('round'),
    supabase.from('case_updates').select('report_id, stage, expected_days, details, created_at').in('report_id', ids).order('created_at'),
    supabase.from('appeals').select('report_id, status, reason, created_at').in('report_id', ids),
  ]);
  if (ev.error || rej.error || upd.error || app.error) throw new Error('load_reports_failed');

  const evidence = group(ev.data);
  const rejections = group(rej.data);
  const updates = group(upd.data);
  const appeals = group(app.data);

  const locIds = [...new Set(reports.map((r) => r.location_id as number))];
  const paths = new Map<number, { en: string | null; bn: string | null }>();
  await Promise.all(
    locIds.map(async (id) => {
      const [en, bn] = await Promise.all([
        supabase.rpc('location_path', { p_id: id, p_lang: 'en' }),
        supabase.rpc('location_path', { p_id: id, p_lang: 'bn' }),
      ]);
      paths.set(id, { en: (en.data as string | null) ?? null, bn: (bn.data as string | null) ?? null });
    }),
  );

  return reports.map((r) => {
    const id = r.report_id as string;
    const u = (updates.get(id) ?? []).map(({ stage, expected_days, details, created_at }) => ({ stage, expected_days, details, created_at }));
    const a = appeals.get(id)?.[0];
    return {
      report_id: id,
      chadabazi_type: r.chadabazi_type,
      amount_demanded: Number(r.amount_demanded),
      incident_date: r.incident_date,
      description: r.description,
      accused_description: r.accused_description,
      fast_track: r.fast_track,
      status: r.status,
      created_at: r.created_at,
      location_en: paths.get(r.location_id as number)?.en ?? null,
      location_bn: paths.get(r.location_id as number)?.bn ?? null,
      evidence: (evidence.get(id) ?? []).map(({ evidence_id, file_type, sha256, uploaded_at }) => ({ evidence_id, file_type, sha256, uploaded_at })),
      rejections: (rejections.get(id) ?? []).map(({ round, rejection_category, reason }) => ({ round, rejection_category, reason })),
      updates: u,
      progress: computeCaseProgress(u),
      appeal: a ? { status: a.status, reason: a.reason, created_at: a.created_at } : null,
    };
  });
}
