'use client';
import { useEffect, useRef, useState } from 'react';
import { createBrowserSupabase } from '@/lib/supabase/client';
import { useI18n } from './I18nProvider';
import { input, label as labelClass } from './ui';

interface Loc {
  location_id: number;
  parent_id: number | null;
  name_en: string;
  name_bn: string;
  level: string;
}
interface Step {
  options: Loc[];
  selected: number | null;
}

/**
 * Cascading location list (FR-05): Division > District > Upazila > Union > Village, or for a city
 * corporation Thana > Ward > Area. Each list is filled from the `locations` table by parent, so
 * the same component handles both flows and any depth of data.
 *
 * onChange(locationId, depth): the deepest choice so far and how many lists are filled in.
 */
export function LocationSelector({ onChange }: { onChange: (locationId: number | null, depth: number) => void }) {
  const { t, lang } = useI18n();
  const [steps, setSteps] = useState<Step[]>([]);
  const [failed, setFailed] = useState(false);
  const client = useRef<ReturnType<typeof createBrowserSupabase> | null>(null);
  const sb = () => (client.current ??= createBrowserSupabase());

  async function fetchChildren(parentId: number | null): Promise<Loc[]> {
    const base = sb().from('locations').select('location_id, parent_id, name_en, name_bn, level');
    const { data, error } = await (parentId === null ? base.is('parent_id', null) : base.eq('parent_id', parentId)).order('name_en');
    if (error) throw error;
    return (data ?? []) as Loc[];
  }

  useEffect(() => {
    fetchChildren(null)
      .then((options) => setSteps([{ options, selected: null }]))
      .catch(() => setFailed(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function choose(index: number, value: string) {
    const id = value === '' ? null : Number(value);
    const kept = steps.slice(0, index + 1).map((s, i) => (i === index ? { ...s, selected: id } : s));
    if (id === null) {
      setSteps(kept);
      onChange(index === 0 ? null : kept[index - 1].selected, index);
      return;
    }
    let children: Loc[] = [];
    try {
      children = await fetchChildren(id);
    } catch {
      setFailed(true);
    }
    setSteps(children.length ? [...kept, { options: children, selected: null }] : kept);
    onChange(id, index + 1);
  }

  if (failed) return <p className="text-sm text-red-700">{t('location.failed')}</p>;

  return (
    <div className="space-y-3">
      {steps.map((s, i) => {
        const levels = [...new Set(s.options.map((o) => t(`level.${o.level}`)))].join(' / ');
        return (
          <div key={i}>
            <label className={labelClass} htmlFor={`loc-${i}`}>
              {levels}
            </label>
            <select id={`loc-${i}`} className={input} value={s.selected ?? ''} onChange={(e) => void choose(i, e.target.value)}>
              <option value="">{t('location.choose')}</option>
              {s.options.map((o) => (
                <option key={o.location_id} value={o.location_id}>
                  {lang === 'bn' ? o.name_bn : o.name_en}
                </option>
              ))}
            </select>
          </div>
        );
      })}
    </div>
  );
}
