'use client';
import type { CaseProgress } from '@/lib/case/progress';
import { formatDate } from '@/lib/client/format';
import { useI18n } from './I18nProvider';
import { card } from './ui';

/** Police case progress as the victim sees it (FR-16): stage, days since filing, expected days remaining, details. */
export function CaseProgressPanel({
  progress,
  updates,
}: {
  progress: CaseProgress;
  updates: { stage: string; expected_days: number | null; details: string | null; created_at: string }[];
}) {
  const { t, lang } = useI18n();
  return (
    <section className={card}>
      <h2 className="mb-3 text-lg font-semibold">{t('case.title')}</h2>
      <dl className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div>
          <dt className="text-xs uppercase text-slate-500">{t('case.stage')}</dt>
          <dd className="font-semibold">{t(`stage.${progress.stage}`)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase text-slate-500">{t('case.daysSince')}</dt>
          <dd className="font-semibold">{t('case.days', { n: progress.daysSinceFiling })}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase text-slate-500">{t('case.remaining')}</dt>
          <dd className="font-semibold">
            {progress.closed
              ? t('case.closed')
              : progress.expectedDaysRemaining === null
                ? t('case.noEstimate')
                : progress.overdue
                  ? t('case.overdue')
                  : t('case.days', { n: progress.expectedDaysRemaining })}
          </dd>
        </div>
      </dl>
      {progress.details ? <p className="mt-3 text-sm text-slate-700">{progress.details}</p> : null}

      <h3 className="mb-2 mt-5 text-sm font-semibold">{t('case.history')}</h3>
      <ol className="space-y-2 border-l-2 border-slate-200 pl-4 text-sm">
        {updates.map((u, i) => (
          <li key={i}>
            <span className="font-medium">{t(`stage.${u.stage}`)}</span>
            <span className="text-slate-500"> · {formatDate(u.created_at, lang)}</span>
            {u.details ? <p className="text-slate-700">{u.details}</p> : null}
          </li>
        ))}
      </ol>
    </section>
  );
}
