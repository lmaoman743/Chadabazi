'use client';
import { useRef, useState } from 'react';
import { createBrowserSupabase } from '@/lib/supabase/client';
import { FILE_LIMITS_MB } from '@/lib/workflow/constants';
import { useI18n } from './I18nProvider';
import { btnGhost, errorBox, noteBox } from './ui';

export interface EvidenceItem {
  evidence_id: string;
  file_type: string;
  sha256: string;
  uploaded_at: string;
}

type Kind = keyof typeof FILE_LIMITS_MB;

function kindOf(file: File): Kind | null {
  const type = file.type;
  if (type.startsWith('image/')) return 'image';
  if (type === 'application/pdf') return 'pdf';
  if (type.startsWith('audio/')) return 'audio';
  if (type.startsWith('video/')) return 'video';
  return null; // unknown from the browser: the server decides from the file's real content
}

/**
 * Evidence upload (FR-09). Files go to the processing service, which removes metadata, compresses,
 * hashes (SHA-256) and stores them privately. The size limits shown here are a convenience; the
 * service enforces the real ones.
 */
export function EvidenceUploader({
  reportId,
  items,
  onChanged,
}: {
  reportId: string;
  items: EvidenceItem[];
  onChanged: () => void;
}) {
  const { t, has } = useI18n();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  async function uploadAll(files: FileList | null) {
    if (!files || files.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      const { data } = await createBrowserSupabase().auth.getSession();
      const token = data.session?.access_token;
      if (!token) {
        setError(t('err.unauthenticated'));
        return;
      }
      for (const file of Array.from(files)) {
        const kind = kindOf(file);
        const limit = (kind ? FILE_LIMITS_MB[kind] : Math.max(...Object.values(FILE_LIMITS_MB))) * 1024 * 1024;
        if (file.size > limit) {
          setError(t('upload.tooLarge', { mb: Math.round(limit / 1024 / 1024) }));
          break;
        }
        const form = new FormData();
        form.append('file', file);
        let res: Response;
        try {
          res = await fetch(`${process.env.NEXT_PUBLIC_PROCESSING_URL}/v1/reports/${reportId}/evidence`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${token}` },
            body: form,
          });
        } catch {
          setError(t('err.network'));
          break;
        }
        if (!res.ok) {
          const body = (await res.json().catch(() => ({}))) as { error?: string };
          const key = `err.${body.error ?? 'generic'}`;
          setError(has(key) ? t(key) : t('err.generic'));
          break;
        }
      }
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
      onChanged();
    }
  }

  return (
    <div className="space-y-3">
      <div className={noteBox}>
        <p>{t('upload.privacy')}</p>
        <p className="mt-1">{t('upload.photosBest')}</p>
        <p className="mt-1">
          {t('upload.limits', { image: FILE_LIMITS_MB.image, pdf: FILE_LIMITS_MB.pdf, audio: FILE_LIMITS_MB.audio, video: FILE_LIMITS_MB.video })}
        </p>
      </div>

      <input
        ref={inputRef}
        type="file"
        multiple
        accept="image/*,application/pdf,audio/*,video/*"
        disabled={busy}
        onChange={(e) => void uploadAll(e.target.files)}
        className="block w-full text-sm file:mr-3 file:rounded-md file:border-0 file:bg-blue-800 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white"
      />
      {busy ? <p className="text-sm text-slate-600">{t('upload.working')}</p> : null}
      {error ? <p className={errorBox}>{error}</p> : null}

      {items.length > 0 ? (
        <ul className="divide-y divide-slate-200 rounded-md border border-slate-200 text-sm">
          {items.map((e) => (
            <li key={e.evidence_id} className="flex flex-wrap items-center gap-2 px-3 py-2">
              <span className="font-semibold">{t(`file.${e.file_type}`)}</span>
              <span className="font-mono text-xs text-slate-500" title={e.sha256}>
                SHA-256 {e.sha256.slice(0, 12)}…
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-slate-600">{t('upload.none')}</p>
      )}
      <button type="button" className={btnGhost} onClick={onChanged}>
        {t('common.refresh')}
      </button>
    </div>
  );
}
